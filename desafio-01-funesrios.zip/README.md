# Entrega del primero desafío 
Hola, un placer ser parte de este curso, estoy con ansias de seguir progresando.

## Notas sobre el desafío
Si bien revisé el texto que me mandaron por via zip, el final al ser un lorem ipsum, no se sabe con claridad si se trata de un texto común y corriente predeterminado o si es un <em> o un <i>
Además de no estar seguro de haber realizado correctamente los pasos a seguir para subir archivos a la nube ya que esta es mi primera vez con git y repositorios, si bien tengo conocimientos básicos de html y css, el subir archivos, convertir en zip, y usar git correctamente fue el verdadero desafío, pero prometo aprender y no volver a cometer los mismos errores.
No he utilizado el git commit -m debido a que primero hice el texto y no tengo versiones anteriores del mismo, recién empecé a usar git init al finalizar todo e incluso hacer el readme.md
Saludos.

````sh
Alejo Funes Rios
````

